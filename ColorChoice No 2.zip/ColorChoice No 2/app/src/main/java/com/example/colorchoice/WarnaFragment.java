import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.example.colorchoice.R;

public class WarnaFragment extends Fragment {

    public WarnaFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_warna, container, false);

        // Ambil argument warna dari bundle
        int warna = getArguments().getInt("warna", Color.WHITE);

        // Set background warna pada view
        view.setBackgroundColor(warna);

        return view;
    }
}