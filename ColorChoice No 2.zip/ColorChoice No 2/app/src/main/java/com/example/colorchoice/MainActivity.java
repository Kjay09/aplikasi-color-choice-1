import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.colorchoice.R;
import com.example.colorchoice.WarnaAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView warnaListView;
    private Button pilihButton;
    private List<Warna> warnaList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi view
        warnaListView = findViewById(R.id.warnaListView);
        pilihButton = findViewById(R.id.pilihButton);

        // Buat daftar warna
        warnaList = new ArrayList<>();
        warnaList.add(new Warna(Color.RED));
        warnaList.add(new Warna(Color.GREEN));
        warnaList.add(new Warna(Color.BLUE));
        warnaList.add(new Warna(Color.YELLOW));
        warnaList.add(new Warna(Color.MAGENTA));

        // Set adapter untuk ListView
        WarnaAdapter adapter = new WarnaAdapter(this, warnaList);
        warnaListView.setAdapter(adapter);

        // Set onClickListener untuk pilihButton
        pilihButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Buka halaman tampilan warna dalam bentuk fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                WarnaFragment warnaFragment = new WarnaFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("warna", warnaList.get(warnaListView.getCheckedItemPosition()).getWarna());
                warnaFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragmentContainer, warnaFragment);
                fragmentTransaction.commit();
            }
        });
    }
}