public class Warna {
    private int warna;

    public Warna(int warna) {
        this.warna = warna;
    }

    public int getWarna() {
        return warna;
    }
}