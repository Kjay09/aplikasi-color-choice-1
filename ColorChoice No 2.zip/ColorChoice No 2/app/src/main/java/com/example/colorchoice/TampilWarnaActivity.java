package com.example.colorchoice;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class TampilWarnaActivity extends AppCompatActivity {

    private GridView warnaGridView;
    private int warna;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_warna);

        // Inisialisasi view
        warnaGridView = findViewById(R.id.warnaGridView);

        // Ambil data warna dari intent
        Intent intent = getIntent();
        warna = intent.getIntExtra("warna", Color.WHITE);

        // Buat daftar warna dalam bentuk bitmap
        List<Bitmap> bitmapList = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            ((ArrayList<?>) bitmapList).add(Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888));
        }

        // Isi bitmap dengan warna yang dipilih
        for (int i = 0; i < bitmapList.size(); i++) {
            Canvas canvas = new Canvas(bitmapList.get(i));
            canvas.drawColor(warna);
        }

        // Set adapter untuk GridView
        warnaGridView.setAdapter(new ImageAdapter(this, bitmapList));
    }

    private class ImageAdapter extends BaseAdapter {

        private Context context;
        private List<Bitmap> bitmapList;

        public ImageAdapter(Context context, List<Bitmap> bitmapList) {
            this.context = context;
            this.bitmapList = bitmapList;
        }

        @Override
        public int getCount() {
            return bitmapList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {
                imageView = new ImageView(context);
                imageView.setLayoutParams(new GridView.LayoutParams(100, 100));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setPadding(16, 16, 16, 16);
            } else {
                imageView = (ImageView) convertView;
            }

            imageView.setImageBitmap(bitmapList.get(position));
            return imageView;
        }
    }
}